ZombieCutscenePack with Alfred's Final Message

Sound ID:
zombie_cutscenes:alfred_mix_01

Test command:
/playsound zombie_cutscenes:alfred_mix_01 master @p ~ ~ ~ 1 1

Use in cutscene JSON:
"sound": "zombie_cutscenes:alfred_mix_01"

This pack is for Minecraft Java 1.20.1.
