CombinedPaintingAndCutscenePack

Includes:
- Your custom painting textures
- Alfred cutscene audio

Sound ID:
zombie_cutscenes:alfred_mix_01

Test command:
/playsound zombie_cutscenes:alfred_mix_01 master @p ~ ~ ~ 2 1 1
