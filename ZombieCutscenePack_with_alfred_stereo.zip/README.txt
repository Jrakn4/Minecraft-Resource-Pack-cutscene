ZombieCutscenePack with Alfred stereo/dual-mono audio

Sound ID:
zombie_cutscenes:alfred_mix_01

Test command:
/playsound zombie_cutscenes:alfred_mix_01 master @p ~ ~ ~ 2 1 1

Use in cutscene JSON:
"sound": "zombie_cutscenes:alfred_mix_01"

Minecraft Java 1.20.1.
